import random

n=random.randint(1000000000000000,9999999999999999)
print(n)

#def walidacja(n):
 # n= [n:-1]
  #
  #return 